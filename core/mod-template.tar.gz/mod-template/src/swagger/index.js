import models from './models'
import tags from './tags'

export default {
  models, tags
}