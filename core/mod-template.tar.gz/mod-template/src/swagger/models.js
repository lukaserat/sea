export const OkResponse = {
  name: 'OkResponse',
  properties: {
    message: {
      type: 'string'
    }
  }
}

export default [
  OkResponse
]