import App from '@viseo/sea'
import path from 'path'
import dotenv from 'dotenv'
import chai from 'chai'
import chaiAsPromised from 'chai-as-promised'

chai.use(chaiAsPromised)
const { assert } = chai

describe('App', () => {
  /** @type {SSC_APP.App} */
  let modInstance
  before(() => {
    dotenv.config({ path: path.join(__dirname, '../.env.test') })
    modInstance = require('./').default
  })

  after(() => {
    modInstance.shutdown()
  })

  it('testing integrity of the app', () => {
    // testing singleton
    const newInstance = App.initialize()
    assert.strictEqual(modInstance, newInstance)
    assert.strictEqual(modInstance.app.modInstance, modInstance)
  })
})