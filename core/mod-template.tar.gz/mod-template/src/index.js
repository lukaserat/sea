import App from '@viseo/sea'

import { addAppKeywords, addAppSchemas } from './validator'
import definition from './definition'


const app = App.initialize(definition)

// add some customization for the app
app.logger.debug('App level schemas and custom key words -->')
addAppSchemas(app)
addAppKeywords(app)

export const logger = app.logger

export default app
